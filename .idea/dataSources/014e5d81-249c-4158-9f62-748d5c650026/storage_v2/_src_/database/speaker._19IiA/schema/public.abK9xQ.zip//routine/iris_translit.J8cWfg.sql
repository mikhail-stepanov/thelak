create function iris_translit(p_string character varying) returns character varying
    immutable
    language sql
as
$$
    --Транслитерация
--Отличие от ГОСТ 7.79-2000
--ё = e, а не yo
--ы = y`, а не y'
select
    replace(
            replace(
                    replace(
                            replace(
                                    replace(
                                            replace(
                                                    replace(
                                                            replace(
                                                                    replace(
                                                                            translate(lower($1),
                                                                                      'абвгдеёзийклмнопрстуфхць', 'abvgdeezijklmnoprstufхc`'),
                                                                            'ж', 'zh'),
                                                                    'ч', 'ch'),
                                                            'ш', 'sh'),
                                                    'щ', 'shh'),
                                            'ъ', '``'),
                                    'ы', 'y`'),
                            'э', 'e`'),
                    'ю', 'yu'),
            'я', 'ya');
$$;

alter function iris_translit(varchar) owner to speaker_user;

